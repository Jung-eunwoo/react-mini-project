import React, { useState } from "react";
import { useSelector } from "react-redux";
import Button from "react-bootstrap/Button";
import Card from "react-bootstrap/Card";
import MoviesCard from "../components/MoviesCard";
import Accordion from "react-bootstrap/Accordion";
import "../style/Movies.css";

const Movies = () => {
  const [dropdownCheck, setDropdownCheck] = useState(false);
  const [selectMovieList, setSelectMovieList] = useState([]);
  const { popularMovies, topRatedMovies, upcomingMovies } = useSelector(
    (state) => state.movie
  );

  // console.log(popularMovies);
  let movieList = [popularMovies, topRatedMovies, upcomingMovies];
  const handleSelect = (e) => {
    setSelectMovieList(movieList[e.target.value]);
  };
  return (
    <div className="movies-container">
      <div className="movies-sort-container">
        {
          <Accordion
            className="movies-sort-dropdown-bar"
            onClick={() => {
              setDropdownCheck(!dropdownCheck);
            }}
          >
            <Accordion.Item eventKey="0">
              <Accordion.Header>정렬</Accordion.Header>
              <Accordion.Body>
                <div className="movies-sort-dropdown-content">
                  <select onChange={handleSelect}>
                    <option value={0}>Popular Movie</option>
                    <option value={1}>Top Rated Movie</option>
                    <option value={2}>Upcoming Movie</option>
                  </select>
                </div>
              </Accordion.Body>
            </Accordion.Item>
          </Accordion>
        }
      </div>
      <div className="movies-card-container">
        {selectMovieList?.map((movie) => (
          <MoviesCard key={movie.id} movie={movie} />
        ))}
      </div>
    </div>
  );
};

export default Movies;
